const express = require('express');
const router = express.Router();
const Report = require('../models/report');

// API untuk mengambil semua data report
router.get('/report', async (req, res) => {
  try {
    const report = await Report.findAll();
    res.json(report);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Terjadi kesalahan saat mengambil data Report' });
  }
});

module.exports = router;
