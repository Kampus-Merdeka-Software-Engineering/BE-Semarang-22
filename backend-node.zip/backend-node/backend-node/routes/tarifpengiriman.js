const express = require('express');
const router = express.Router();
const TarifPengiriman = require('../models/tarifpengiriman');

// API untuk mengambil semua data tarif pengiriman
router.get('/tarifpengiriman', async (req, res) => {
  try {
    const tarifPengiriman = await TarifPengiriman.findAll();
    res.json(tarifPengiriman);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Terjadi kesalahan saat mengambil data Tarif Pengiriman' });
  }
});

module.exports = router;
