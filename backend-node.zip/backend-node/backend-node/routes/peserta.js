const express = require('express');
const router = express.Router();
const Peserta = require('../models/peserta.js');

// API untuk mengambil semua data peserta       
router.get('/peserta', async (req, res) => {
  try {
    const peserta = await Peserta.findAll();
    res.json(peserta);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Terjadi kesalahan saat mengambil data Peserta' });
  }
});

module.exports = router;
