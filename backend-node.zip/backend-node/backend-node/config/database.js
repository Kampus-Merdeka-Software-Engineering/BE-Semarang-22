const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('tutorial', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
});

sequelize
  .authenticate()
  .then(() => {
    console.log('Koneksi ke database berhasil.');
  })
  .catch((err) => {
    console.error('Tidak dapat terhubung ke database:', err);
  });

module.exports = sequelize;

