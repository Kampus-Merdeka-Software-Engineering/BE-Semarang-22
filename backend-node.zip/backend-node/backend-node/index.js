const express = require('express');
const app = express();
const cors = require('cors');
const pesertaRoutes = require('./routes/peserta'); 
const reportRoutes = require('./routes/report'); 
const tarifPengirimanRoutes = require('./routes/tarifpengiriman');
const usersRoutes = require('./routes/users'); 
const bodyParser = require('body-parser');

app.use('/api', pesertaRoutes);
app.use('/api', reportRoutes);
app.use('/api', tarifPengirimanRoutes);
app.use('/api', usersRoutes);
app.use(cors())
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/api/peserta', async (req, res) => {
});

app.post('/api/peserta', async (req, res) => {
  const { no_resi, nama_pengirim, nama_penerima, alamat, no_hp, keterangan } = req.body;
  res.json({
    message: "create data berhasil",
    data: {
      no_resi: no_resi,
      nama_pengirim: nama_pengirim,
      nama_penerima: nama_penerima,
      alamat: alamat,
      no_hp: no_hp,
      keterangan: keterangan
    }
  })
});

app.get('/api/report', async (req, res) => {
});

app.post('/api/report', async (req, res) => {
  const { no_resi, nama, email, no_hp, pesan } = req.body;
  res.json({
    message: "create data berhasil",
    data: {
      no_resi: no_resi,
      nama: nama,
      email: email ,
      no_hp: no_hp,
      pesan: pesan,
    }
  })
});

app.get('/api/tarifpengiriman', async (req, res) => {
});

app.get('/api/users', async (req, res) => {
});

app.post('/api/users', async (req, res) => {
  res.json({
    message: "create data berhasil",
})
});
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server berjalan di port ${PORT}`);
});
