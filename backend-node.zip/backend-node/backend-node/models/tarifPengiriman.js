const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const TarifPengiriman = sequelize.define('TarifPengiriman', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true, // Menandakan bahwa kolom ini adalah primary key
    autoIncrement: true // Menandakan bahwa nilai akan otomatis bertambah
  },
  kota_asal: DataTypes.STRING,
  kota_tujuan: DataTypes.STRING,
  berat_max: DataTypes.FLOAT,
  tarif: DataTypes.FLOAT,
  jenis_barang: DataTypes.STRING,
});

module.exports = TarifPengiriman;
