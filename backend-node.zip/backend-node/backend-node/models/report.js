const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Report = sequelize.define('Report', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true, // Menandakan bahwa kolom ini adalah primary key
    autoIncrement: true // Menandakan bahwa nilai akan otomatis bertambah
  },
  no_resi: DataTypes.STRING,
  nama: DataTypes.STRING,
  email: DataTypes.STRING,
  no_hp: DataTypes.STRING,
  pesan: DataTypes.STRING,
});

module.exports = Report;
