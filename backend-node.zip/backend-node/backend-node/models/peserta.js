const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Peserta = sequelize.define('peserta', {
  id_peserta: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  no_resi: DataTypes.STRING,
  nama_pengirim: DataTypes.STRING,
  nama_penerima: DataTypes.STRING,
  alamat: DataTypes.STRING,
  no_hp: DataTypes.CHAR,
  keterangan: DataTypes.STRING,
}, {
  timestamps: false, // Disable timestamps
});

module.exports = Peserta;
