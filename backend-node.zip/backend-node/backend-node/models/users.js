const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const users = sequelize.define('users', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  Username: DataTypes.STRING,
  Email: DataTypes.STRING,
  Age: DataTypes.INTEGER,
  Password: DataTypes.STRING,
}, {
  timestamps: false, // Disable timestamps
});

module.exports = users;
